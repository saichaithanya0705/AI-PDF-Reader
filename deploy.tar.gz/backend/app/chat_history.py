"""
Chat History Manager Module

Handles persistence of chat conversations to database.
Supports both Supabase (production) and SQLite (local) storage.
"""

import os
import json
import sqlite3
from typing import List, Dict, Any, Optional
from datetime import datetime
from pathlib import Path
import uuid

# Check if Supabase is available
try:
    from supabase import create_client, Client
    SUPABASE_AVAILABLE = True
except ImportError:
    SUPABASE_AVAILABLE = False
    print("⚠️ Supabase not available, using SQLite for chat history")


class ChatHistoryManager:
    """Manages chat conversation history with database persistence"""
    
    def __init__(self):
        """Initialize chat history manager with appropriate storage backend"""
        self.use_supabase = os.getenv("USE_SUPABASE", "false").lower() == "true"
        
        if self.use_supabase and SUPABASE_AVAILABLE:
            self._init_supabase()
        else:
            self._init_sqlite()
    
    def _init_supabase(self):
        """Initialize Supabase client"""
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_SERVICE_KEY")
        
        if not supabase_url or not supabase_key:
            print("⚠️ Supabase credentials not found, falling back to SQLite")
            self.use_supabase = False
            self._init_sqlite()
            return
        
        try:
            self.supabase: Client = create_client(supabase_url, supabase_key)
            self._create_supabase_tables()
            print("✅ Chat history using Supabase")
        except Exception as e:
            print(f"❌ Supabase initialization failed: {e}")
            self.use_supabase = False
            self._init_sqlite()
    
    def _create_supabase_tables(self):
        """Create Supabase tables if they don't exist"""
        # Tables are created via Supabase migrations
        # This is a placeholder for table verification
        pass
    
    def _init_sqlite(self):
        """Initialize SQLite database for chat history"""
        # Store in backend data directory
        base_dir = Path(__file__).parent.parent
        db_dir = base_dir / "data"
        db_dir.mkdir(exist_ok=True)
        
        self.db_path = db_dir / "chat_history.db"
        self._create_sqlite_tables()
        print(f"✅ Chat history using SQLite: {self.db_path}")
    
    def _create_sqlite_tables(self):
        """Create SQLite tables for chat history"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Chat sessions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chat_sessions (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                title TEXT,
                context_type TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        
        # Chat messages table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chat_messages (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                metadata TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES chat_sessions (id) ON DELETE CASCADE
            )
        """)
        
        # Create indexes for faster queries
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_sessions_user 
            ON chat_sessions(user_id, created_at DESC)
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_messages_session 
            ON chat_messages(session_id, created_at ASC)
        """)
        
        conn.commit()
        conn.close()
    
    async def create_session(
        self,
        user_id: str,
        title: Optional[str] = None,
        context_type: str = "library"
    ) -> str:
        """
        Create a new chat session
        
        Args:
            user_id: User identifier
            title: Optional session title
            context_type: 'library' or 'pdf_viewer'
            
        Returns:
            Session ID
        """
        session_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        
        if not title:
            title = f"Chat {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        
        if self.use_supabase:
            self.supabase.table("chat_sessions").insert({
                "id": session_id,
                "user_id": user_id,
                "title": title,
                "context_type": context_type,
                "created_at": now,
                "updated_at": now
            }).execute()
        else:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO chat_sessions (id, user_id, title, context_type, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (session_id, user_id, title, context_type, now, now))
            conn.commit()
            conn.close()
        
        return session_id
    
    async def save_message(
        self,
        user_id: str,
        session_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """
        Save a chat message to the database
        
        Args:
            user_id: User identifier
            session_id: Chat session ID
            role: 'user' or 'assistant'
            content: Message content
            metadata: Optional metadata (related_documents, context, etc.)
        """
        message_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        metadata_json = json.dumps(metadata) if metadata else None
        
        # Create session if it doesn't exist (for backward compatibility)
        if session_id == "default":
            # Check if default session exists for this user
            existing = await self.get_session(session_id, user_id)
            if not existing:
                session_id = await self.create_session(user_id, "Default Conversation")
        
        if self.use_supabase:
            self.supabase.table("chat_messages").insert({
                "id": message_id,
                "session_id": session_id,
                "role": role,
                "content": content,
                "metadata": metadata,
                "created_at": now
            }).execute()
            
            # Update session timestamp
            self.supabase.table("chat_sessions").update({
                "updated_at": now
            }).eq("id", session_id).execute()
        else:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO chat_messages (id, session_id, role, content, metadata, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (message_id, session_id, role, content, metadata_json, now))
            
            cursor.execute("""
                UPDATE chat_sessions SET updated_at = ? WHERE id = ?
            """, (now, session_id))
            
            conn.commit()
            conn.close()
    
    async def get_session_history(
        self,
        session_id: str,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieve conversation history for a session
        
        Args:
            session_id: Chat session ID
            limit: Optional limit on number of messages
            
        Returns:
            List of messages with role, content, metadata, and timestamp
        """
        if self.use_supabase:
            query = self.supabase.table("chat_messages").select("*").eq("session_id", session_id).order("created_at", desc=False)
            
            if limit:
                query = query.limit(limit)
            
            result = query.execute()
            messages = result.data
            
            # Parse metadata from JSON
            for msg in messages:
                if msg.get("metadata"):
                    msg["metadata"] = json.loads(msg["metadata"]) if isinstance(msg["metadata"], str) else msg["metadata"]
            
            return messages
        else:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = "SELECT * FROM chat_messages WHERE session_id = ? ORDER BY created_at ASC"
            params = [session_id]
            
            if limit:
                query += " LIMIT ?"
                params.append(limit)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            conn.close()
            
            messages = []
            for row in rows:
                msg = dict(row)
                if msg.get("metadata"):
                    msg["metadata"] = json.loads(msg["metadata"])
                messages.append(msg)
            
            return messages
    
    async def list_user_sessions(
        self,
        user_id: str,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Get all chat sessions for a user
        
        Args:
            user_id: User identifier
            limit: Maximum number of sessions to return
            
        Returns:
            List of session dictionaries
        """
        if self.use_supabase:
            result = self.supabase.table("chat_sessions").select("*").eq("user_id", user_id).order("updated_at", desc=True).limit(limit).execute()
            return result.data
        else:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM chat_sessions 
                WHERE user_id = ? 
                ORDER BY updated_at DESC 
                LIMIT ?
            """, (user_id, limit))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
    
    async def get_session(
        self,
        session_id: str,
        user_id: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Get a specific session by ID
        
        Args:
            session_id: Chat session ID
            user_id: Optional user ID for verification
            
        Returns:
            Session dictionary or None
        """
        if self.use_supabase:
            query = self.supabase.table("chat_sessions").select("*").eq("id", session_id)
            if user_id:
                query = query.eq("user_id", user_id)
            
            result = query.execute()
            return result.data[0] if result.data else None
        else:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if user_id:
                cursor.execute("SELECT * FROM chat_sessions WHERE id = ? AND user_id = ?", (session_id, user_id))
            else:
                cursor.execute("SELECT * FROM chat_sessions WHERE id = ?", (session_id,))
            
            row = cursor.fetchone()
            conn.close()
            
            return dict(row) if row else None
    
    async def delete_session(
        self,
        session_id: str,
        user_id: str
    ) -> bool:
        """
        Delete a chat session and all its messages
        
        Args:
            session_id: Chat session ID
            user_id: User ID (for verification)
            
        Returns:
            True if deleted, False if not found or unauthorized
        """
        # Verify ownership
        session = await self.get_session(session_id, user_id)
        if not session:
            return False
        
        if self.use_supabase:
            # Delete messages first (cascade should handle this, but being explicit)
            self.supabase.table("chat_messages").delete().eq("session_id", session_id).execute()
            self.supabase.table("chat_sessions").delete().eq("id", session_id).execute()
        else:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            # SQLite cascade will delete messages
            cursor.execute("DELETE FROM chat_sessions WHERE id = ? AND user_id = ?", (session_id, user_id))
            
            conn.commit()
            conn.close()
        
        return True


# Global instance
_chat_history_manager = None

def get_chat_history_manager() -> ChatHistoryManager:
    """Get or create the global chat history manager instance"""
    global _chat_history_manager
    if _chat_history_manager is None:
        _chat_history_manager = ChatHistoryManager()
    return _chat_history_manager
